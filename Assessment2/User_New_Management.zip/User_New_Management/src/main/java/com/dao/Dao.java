package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.SignupMod;

public class Dao 
{
public static Connection getconnect()
{
	Connection con = null;
	
	try 
	{
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userprofile_register","root","");
	}
	catch (Exception e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	return con;
}

public static int signup(SignupMod m)
{
	Connection con = Dao.getconnect();
	int status = 0;
	
	try 
	{
		PreparedStatement ps = con.prepareStatement("insert into student(fname,lname,email,phone,password) values (?,?,?,?,?)");

		ps.setString(1,m.getFname());
		ps.setString(2,m.getLname());
		ps.setString(3,m.getEmail());
		ps.setString(4,m.getPhone());
		ps.setString(5,m.getPassword());
		
		status = ps.executeUpdate();
	} 
	catch (Exception e)
	{
		e.printStackTrace();
		e.printStackTrace();
	}
	
	return status;
}

//login method
public static SignupMod login(SignupMod m)
{
	Connection con = Dao.getconnect();
	SignupMod m2 = null;
	
	try 
	{
		PreparedStatement ps = con.prepareStatement("select * from student where email=? and password=?");

		ps.setString(1,m.getEmail());
		ps.setString(2,m.getPassword());
		
		
		ResultSet set = ps.executeQuery();
		
		if(set.next())
		{
			int id = set.getInt(1);
			String fname = set.getString(2);
			String lname = set.getString(3);
			String email = set.getString(4);
			String phone = set.getString(5);
			String password = set.getString(6);
			
			m2 = new SignupMod();
			m2.setId(id);
			m2.setFname(fname);
			m2.setLname(lname);
			m2.setEmail(email);
			m2.setPassword(password);
			m2.setPhone(phone);				
		}
		else
		{
			System.out.println("Invalid Credentials");
		}
	} 
	catch (Exception e)
	{
		e.printStackTrace();
		
	}
	
	return m2;
}


//get-fetch for edit
//public static SignupMod Edit(int id)
//{
//	Connection con = Dao.getconnect();//connection call
//	
//	int Status = 0;
//	SignupMod m =null;
//	try 
//	{
//		PreparedStatement ps = con.prepareStatement("select * from info where id=?");
//		ps.setInt(1,id);
//		
//		ResultSet set = ps.executeQuery();
//		
//		if(set.next())
//		{
//			int id2 = set.getInt(1);
//			String fname = set.getString(2);
//			String lname = set.getString(3);
//			String email = set.getString(4);
//			String phone = set.getString(5);
//			String password = set.getString(6);
//		
//			m = new SignupMod();
//			m.setId(id2);
//			m.setFname(fname);
//			m.setLname(lname);
//			m.setEmail(email);
//			
//			m.setPhone(phone);
//		}
//		
//	} 
//	catch (Exception e)
//	{
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//	
//	return m;
//}

//update method
public static int update(SignupMod m, String oldPassword) {
    Connection con = Dao.getconnect();
    int status = 0;

    try {
        // Step 1: Retrieve the stored password from the database based on the email
        PreparedStatement ps1 = con.prepareStatement("SELECT password FROM student WHERE email = ?");
        ps1.setString(1, m.getEmail());
        ResultSet rs = ps1.executeQuery();

        if (rs.next()) {
            String storedPassword = rs.getString("password");

            // Step 2: Compare the old password with the stored password
            if (storedPassword.equals(oldPassword)) {
                // Step 3: If passwords match, proceed to update the password
                PreparedStatement ps2 = con.prepareStatement("UPDATE student SET password=? WHERE email=?");
                ps2.setString(1, m.getPassword());  // New password to be updated
                ps2.setString(2, m.getEmail());
                
                status = ps2.executeUpdate();  // Execute the update query
            } else {
                System.out.println("Old password does not match!");
                // Optionally, handle this case with an error or status code
            }
        } else {
            System.out.println("No user found with the given email!");
            // Optionally, handle this case with an error or status code
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return status;
}

	
	public static SignupMod forget(SignupMod m)
	{
		Connection con = Dao.getconnect();
		SignupMod m2 = null;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("select * from student where email=?");

			ps.setString(1,m.getEmail());
			
			
			
			ResultSet set = ps.executeQuery();
			
			if(set.next())
			{
				int id = set.getInt(1);
				String fname = set.getString(2);
				String lname = set.getString(3);
				String email = set.getString(4);
				String phone = set.getString(5);
				String password = set.getString(6);
				
				m2 = new SignupMod();
				m2.setId(id);
				m2.setFname(fname);
				m2.setLname(lname);
				m2.setEmail(email);
				m2.setPassword(password);
				m2.setPhone(phone);				
			}
			else
			{
				System.out.println("Invalid Email");
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			
		}
		
		return m2;
	}

	}