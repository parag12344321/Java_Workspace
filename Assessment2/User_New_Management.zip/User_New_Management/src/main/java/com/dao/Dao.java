package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.model.SignupMod;

public class Dao 
{
public static Connection getconnect()
{
	Connection con = null;
	
	try 
	{
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userprofile_register","root","");
	}
	catch (Exception e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	return con;
}

public static int signup(SignupMod m)
{
	Connection con = Dao.getconnect();
	int status = 0;
	
	try 
	{
		PreparedStatement ps = con.prepareStatement("insert into student(fname,lname,email,phone,password) values (?,?,?,?,?)");

		ps.setString(1,m.getFname());
		ps.setString(2,m.getLname());
		ps.setString(3,m.getEmail());
		ps.setString(4,m.getPhone());
		ps.setString(5,m.getPassword());
		
		status = ps.executeUpdate();
	} 
	catch (Exception e)
	{
		e.printStackTrace();
		e.printStackTrace();
	}
	
	return status;
}

//login method
public static SignupMod login(SignupMod m)
{
	Connection con = Dao.getconnect();
	SignupMod m2 = null;
	
	try 
	{
		PreparedStatement ps = con.prepareStatement("select * from student where email=? and password=?");

		ps.setString(1,m.getEmail());
		ps.setString(2,m.getPassword());
		
		
		ResultSet set = ps.executeQuery();
		
		if(set.next())
		{
			int id = set.getInt(1);
			String fname = set.getString(2);
			String lname = set.getString(3);
			String email = set.getString(4);
			String phone = set.getString(5);
			String password = set.getString(6);
			
			m2 = new SignupMod();
			m2.setId(id);
			m2.setFname(fname);
			m2.setLname(lname);
			m2.setEmail(email);
			m2.setPassword(password);
			m2.setPhone(phone);				
		}
		else
		{
			System.out.println("Invalid Credentials");
		}
	} 
	catch (Exception e)
	{
		e.printStackTrace();
		
	}
	
	return m2;
}


//get-fetch for edit
//public static SignupMod Edit(int id)
//{
//	Connection con = Dao.getconnect();//connection call
//	
//	int Status = 0;
//	SignupMod m =null;
//	try 
//	{
//		PreparedStatement ps = con.prepareStatement("select * from info where id=?");
//		ps.setInt(1,id);
//		
//		ResultSet set = ps.executeQuery();
//		
//		if(set.next())
//		{
//			int id2 = set.getInt(1);
//			String fname = set.getString(2);
//			String lname = set.getString(3);
//			String email = set.getString(4);
//			String phone = set.getString(5);
//			String password = set.getString(6);
//		
//			m = new SignupMod();
//			m.setId(id2);
//			m.setFname(fname);
//			m.setLname(lname);
//			m.setEmail(email);
//			
//			m.setPhone(phone);
//		}
//		
//	} 
//	catch (Exception e)
//	{
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//	
//	return m;
//}

//update method
	public static int update(SignupMod m)
	{
		Connection con = Dao.getconnect();
		
		int status = 0;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("update student set password=? where email=?");

			/*ps.setString(1,m.getFname());
			ps.setString(2,m.getLname());
			
			ps.setString(4,m.getPhone());*/
			ps.setString(1,m.getPassword());
			ps.setString(2,m.getEmail());
			
			status = ps.executeUpdate();
			
			//ResultSet set = ps.executeQuery();
			
		
			/*if(set.next())
			{
				int id = set.getInt(1);
				String fname = set.getString(2);
				String lname = set.getString(3);
				String email = set.getString(4);
				String phone = set.getString(5);
				String password = set.getString(6);
				
				m = new SignupMod();
				m.setId(id);
				m.setFname(fname);
				m.setLname(lname);
				m.setEmail(email);
				m.setPassword(password);
				m.setPhone(phone);				
			}
			else
			{
				System.out.println("Password Not Change");
			}*/
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			
		}
		
		return status;
		
		}
	
	public static SignupMod forget(SignupMod m)
	{
		Connection con = Dao.getconnect();
		SignupMod m2 = null;
		
		try 
		{
			PreparedStatement ps = con.prepareStatement("select * from student where email=?");

			ps.setString(1,m.getEmail());
			
			
			
			ResultSet set = ps.executeQuery();
			
			if(set.next())
			{
				int id = set.getInt(1);
				String fname = set.getString(2);
				String lname = set.getString(3);
				String email = set.getString(4);
				String phone = set.getString(5);
				String password = set.getString(6);
				
				m2 = new SignupMod();
				m2.setId(id);
				m2.setFname(fname);
				m2.setLname(lname);
				m2.setEmail(email);
				m2.setPassword(password);
				m2.setPhone(phone);				
			}
			else
			{
				System.out.println("Invalid Email");
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			
		}
		
		return m2;
	}

	}