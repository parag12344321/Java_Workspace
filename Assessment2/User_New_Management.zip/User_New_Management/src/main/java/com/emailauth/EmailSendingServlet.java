package com.emailauth;

import java.io.IOException;
import java.io.PrintWriter;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/EmailSendingServlet")
public class EmailSendingServlet extends HttpServlet
{
	String resultMessage = "";
	private String host;
	private String port;
	private String user;
	private String pass;
	
	@Override
	public void init() throws ServletException 
	{
		ServletContext context = getServletContext();
		host = context.getInitParameter("host");
		port = context.getInitParameter("port");
		user = context.getInitParameter("user");
		pass = context.getInitParameter("pass");
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		//super.doGet(req, resp);
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		Object recipient = req.getAttribute("e1");
        String data = (String) recipient;
		
		String subject = "Welcome to User Management System";
		
        HttpSession sess = req.getSession();
		
		int n1 = (int) sess.getAttribute("n1");
		int n2 = (int) sess.getAttribute("n2");
		int n3 = (int) sess.getAttribute("n3");
		int n4 = (int) sess.getAttribute("n4");
		
		String content = "Welcome to User Management System Your Verification OTP is "+n1+n2+n3+n4;
	
		try 
		{
			
			EmailUtility.sendEmail(host, port, user, pass, data, subject,content);
			
			
			resp.sendRedirect("otpsend.jsp");
		}
		catch (AddressException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (MessagingException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try 
		{
			Thread.sleep(3000);
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		resultMessage = "The e-mail was sent successfully";
	}

}
