import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the user input from the form
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Example check for username and password (hardcoded for simplicity)
        if (password.equals(password) && email.equals(email)) {
            // Redirect to a welcome page if login is successful
            response.sendRedirect("success.jsp");
        } else {
            // Display an error message if login fails
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h3>Invalid username or password</h3>");
            out.println("</body></html>");
        }
    }
}
