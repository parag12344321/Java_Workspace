import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/VerifyOtpServlet")
public class VerifyOtpServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String otpEntered = request.getParameter("otp");
        
        Connection conn = DatabaseConnection.getconnect();
        PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement("SELECT * FROM student WHERE email=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			ps.setString(1, email);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        ResultSet rs = null;
		try {
			rs = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        try {
			if (rs.next()) {
			    String otpStored = rs.getString("otp");
			    
			    if (otpEntered.equals(otpStored)) {
			        PreparedStatement updatePS = conn.prepareStatement("UPDATE student SET login_status='verified' WHERE email=?");
			        updatePS.setString(1, email);
			        updatePS.executeUpdate();
			        response.sendRedirect("login.jsp?success=otp_verified");
			    } else {
			        response.sendRedirect("otp.jsp?error=otp_failed");
			    }
			} else {
			    response.sendRedirect("otp.jsp?error=email_not_found");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
