import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        
        if (password.equals(confirmPassword)) {
            // Check if email already exists in the database
            Connection conn = DatabaseConnection.getconnect();
            PreparedStatement ps = null;
			try {
				ps = conn.prepareStatement("SELECT * FROM student WHERE email=?");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            try {
				ps.setString(1, email);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            ResultSet rs = null;
			try {
				rs = ps.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            try {
				if (rs.next()) {
				    // Email already registered
				    response.sendRedirect("signup.jsp?error=email_taken");
				} else {
				    // Insert user into the database
				    PreparedStatement insertPS = conn.prepareStatement("INSERT INTO student (email, password) VALUES (?, ?)");
				    insertPS.setString(1, email);
				    insertPS.setString(2, password);
				    insertPS.executeUpdate();
				    
				    // Send OTP email
				    String otp = generateOTP();
				    sendOTPEmail(email, otp);
				    
				    // Update OTP in database
				    PreparedStatement updatePS = conn.prepareStatement("UPDATE student SET otp=? WHERE email=?");
				    updatePS.setString(1, otp);
				    updatePS.setString(2, email);
				    updatePS.executeUpdate();
				    
				    response.sendRedirect("otp.jsp?email=" + email);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        } else {
            response.sendRedirect("signup.jsp?error=password_mismatch");
        }
    }
    
    private String generateOTP() {
        Random rand = new Random();
        return String.format("%04d", rand.nextInt(10000));
    }
    
    private void sendOTPEmail(String toEmail, String otp) {
        String fromEmail = "paragmehta100@gmail.com";
        String host = "smtp.gmail.com";
        
        Properties properties = System.getProperties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.auth", "true");
        
        Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, "Parag@27121983");
            }
        });
        
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromEmail));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
            message.setSubject("OTP Verification");
            message.setText("Your OTP is: " + otp);
            Transport.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
