import java.io.*;
import javax.servlet.*;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/genericservlet")
public class GenericServletExample extends GenericServlet {

    // Override the service method
    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        // Set the content type of the response
        response.setContentType("text/html");
        
        // Write response using PrintWriter
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>GenericServlet: Hello World</h2>");
        out.println("</body></html>");
    }
}
