import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter("/*") // This makes the filter apply to all incoming requests
public class InputValidationFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Filter initialization, if needed
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // Example: Validate user inputs (you can extend this to more complex validation logic)
        String username = httpRequest.getParameter("username");
        String email = httpRequest.getParameter("email");

        // Validate username (non-empty, alphanumeric)
        if (username == null || username.trim().isEmpty() || !username.matches("^[a-zA-Z0-9_]+$")) {
            httpResponse.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid username. Only alphanumeric characters are allowed.");
            return;
        }

        // Validate email (basic format check)
        if (email == null || !email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            httpResponse.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid email format.");
            return;
        }

        // Continue with the request processing if validation passes
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Cleanup if needed
    }
}

