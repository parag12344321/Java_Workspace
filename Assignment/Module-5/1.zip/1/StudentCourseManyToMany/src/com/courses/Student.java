package com.courses;

import java.util.List;

import javax.persistence.*;


import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Students")
public class Student 
{
	@Id
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment",strategy="increment")
	@Column(name="Stid")
	int id;
	
	@Column(name="Sname")
	String Sname;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQname() {
		return Sname;
	}

	public void setQname(String qname) {
		this.Sname = qname;
	}
	
	@ManyToMany(targetEntity = Course.class, cascade = { CascadeType.ALL })
	
	@JoinTable(name = "Student_Courses", joinColumns = { @JoinColumn(name = "st_id") }, inverseJoinColumns = { @JoinColumn(name = "course_id") })
	
	
	private List<Course> courses;

	public List<Course> getAnswers() {
		return courses;
	}

	public void setAnswers(List<Course> answers) {
		this.courses = answers;
	}
	
	
	
	
	
	
	
	
}
