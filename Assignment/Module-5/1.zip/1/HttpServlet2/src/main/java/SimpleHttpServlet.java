import javax.servlet.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;

public class SimpleHttpServlet extends HttpServlet {

    // Handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the content type to HTML
        response.setContentType("text/html");

        // Get the output stream to write the response
        PrintWriter out = response.getWriter();

        // Write HTML response
        out.println("<html><body>");
        out.println("<h1>This is a GET request response</h1>");
        out.println("<form method='POST' action='simpleHttpServlet'>");
        out.println("<input type='text' name='username' placeholder='Enter your name'>");
        out.println("<input type='submit' value='Submit'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    // Handle POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the content type to HTML
        response.setContentType("text/html");

        // Get the output stream to write the response
        PrintWriter out = response.getWriter();

        // Retrieve the form parameter
        String username = request.getParameter("username");

        // Write HTML response
        out.println("<html><body>");
        if (username != null && !username.isEmpty()) {
            out.println("<h1>Welcome, " + username + "!</h1>");
        } else {
            out.println("<h1>Username is empty. Please try again.</h1>");
        }
        out.println("<a href='simpleHttpServlet'>Go back</a>");
        out.println("</body></html>");
    }
}
