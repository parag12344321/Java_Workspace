package com.example;

import java.io.*;
import javax.servlet.*;


import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Servlet1 extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch shared data from ServletContext
        ServletContext context = getServletContext();
        String companyName = context.getInitParameter("companyName");
        String appVersion = context.getInitParameter("appVersion");

        // Set the response content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Print the shared data
        out.println("<html><body>");
        out.println("<h2>Servlet 1</h2>");
        out.println("<p>Company Name: Tops. " + companyName + "</p>");
        out.println("<p>App Version: " + appVersion + "</p>");
        out.println("</body></html>");
    }
}

