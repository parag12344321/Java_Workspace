import javax.servlet.*;
import javax.servlet.http.*;

import jakarta.servlet.annotation.WebServlet;

import java.io.*;
@WebServlet
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        RequestDispatcher dispatcher;

        // Simple validation for demonstration
        if ("admin".equals(username) && "password123".equals(password)) {
            // Forward to success page if valid
            dispatcher = request.getRequestDispatcher("success.jsp");
        } else {
            // Include error message and stay on the login form
            request.setAttribute("error", "Invalid username or password.");
            dispatcher = request.getRequestDispatcher("login.jsp");
        }

        dispatcher.forward(request, response);
    }
}
