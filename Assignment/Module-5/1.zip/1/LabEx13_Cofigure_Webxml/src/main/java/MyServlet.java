import java.io.*;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class MyServlet extends HttpServlet 
{
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set content type to text/html
        response.setContentType("text/html");
        
        // Write response message
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Hello, welcome to my servlet!</h1>");
        out.println("</body></html>");
    }
}
