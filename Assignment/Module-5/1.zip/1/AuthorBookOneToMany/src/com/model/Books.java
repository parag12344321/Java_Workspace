package com.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Books3")
public class Books 
{
	@OneToMany
	
	List<Author>list;
	
	public List<Author> getList() {
		return list;
	}
	public void setList(List<Author> list) {
		this.list = list;
	}
	@Id
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment",strategy="increment")
	@Column(name="Bookid")
	
private int id;
	@Column(name="Books")
private String bk;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAddr() {
	return bk;
}
public void setAddr(String addr) {
	this.bk = addr;
}

}
