package com.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.connect.Util;
import com.model.Books;
import com.model.Author;

public class MainClass 
{
	public static void main(String[] args)
	{
		
		Session sess =  new Util().getConnect();
		Transaction tr = sess.beginTransaction();
		
		Author p = new Author();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Authorname:");
		p.setName(sc.next());
		
		Author p2 = new Author();
		System.out.println("Enter Authorname2:");
		p2.setName(sc.next());
		
		Books ad = new Books();
		System.out.println("Enter Bookname:");
		ad.setAddr(sc.next());
		
		List<Author>list = new ArrayList<Author>();
		list.add(p);
		list.add(p2);
		
		ad.setList(list);
		
		sess.save(p);
		sess.save(p2);
		sess.save(ad);
		tr.commit();
		sess.close();
	}
}
