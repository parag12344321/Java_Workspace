package com.controller;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.connect.Util;
import com.model.Profile;
import com.model.User;

public class Mainclass 
{
	public static void main(String[] args) 
	{
	
		Session sess =  new Util().getConnect();
		Transaction tr = sess.beginTransaction();
		User p = new User();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Username:");
		p.setName(sc.next());
		Profile ad = new Profile();
		System.out.println("Enter Profile:");
		ad.setAddr(sc.next());
		ad.setPerson(p);
		sess.save(p);
		sess.save(ad);
		tr.commit();
		sess.close();
}
}
