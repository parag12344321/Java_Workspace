package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="profile")
public class Profile {
	@OneToOne
	private User person;
	
	public User getPerson() {
		return person;
	}
	public void setPerson(User person) {
		this.person = person;
	}
	@Id
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment",strategy="increment")
	@Column(name="pid")
	
private int id;
	@Column(name="Prof1")
private String profl;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAddr() {
	return profl;
}
public void setAddr(String addr) {
	this.profl = addr;
}

}
