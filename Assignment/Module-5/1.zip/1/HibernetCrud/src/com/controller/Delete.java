package com.controller;

import java.util.Scanner;

import com.dao.Dao;
import com.model.Employee;


public class Delete 
{
	public static void main(String[] args) 
	{
Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Your Id");
		int id = sc.nextInt();
		
		Employee p = new Employee();
		p.setId(id);
		
		
		new Dao().delete(p);
	}
}
