package com.controller;

import java.util.Scanner;

import com.dao.Dao;
import com.model.Employee;


public class Update 
{
	public static void main(String[] args) 
	{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Your Id");
		int id = sc.nextInt();
		
		System.out.println("Enter Your Name");
		String name = sc.next();
		
		System.out.println("Enter Department");
		String department = sc.next();
		
		System.out.println("Enter salary");
		int salary = sc.nextInt();
		
	
		Employee p = new Employee();
		p.setId(id);
		p.setName(name);
		p.setDepartment(department);
		p.setSalary(salary);
		
		new Dao().update(p);
	}
}
