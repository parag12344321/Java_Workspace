package com.controller;

import java.util.Scanner;

import com.dao.Dao;
import com.model.Employee;


public class Insert 
{
	public static void main(String[] args) 
	{
		
		System.out.println("Enter Your Name");
		Scanner sc = new Scanner(System.in);
		String name = sc.next();
		
		System.out.println("Enter Department");
		String department = sc.next();
		
		System.out.println("Enter Salary");
		int salary = sc.nextInt();
		
		Employee p = new Employee();
		p.setName(name);
		p.setDepartment(department);
		p.setSalary(salary);
		
		new Dao().insert(p);
	}
}
