package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.connect.Util;
import com.model.Employee;


public class Dao 
{
	public void insert(Employee p)
	{
		Session sess = new Util().getconnect();
		Transaction tr = sess.beginTransaction();
		sess.save(p);
		tr.commit();
		sess.close();
	}
	
	public void delete(Employee p)
	{
		Session sess = new Util().getconnect();
		Transaction tr = sess.beginTransaction();
		sess.delete(p);
		tr.commit();
		sess.close();
	}
	
	
	public void update(Employee p)
	{
		Session sess = new Util().getconnect();
		Transaction tr = sess.beginTransaction();
		sess.update(p);
		tr.commit();
		sess.close();
	}
	
	public List<Employee> viewdata()
	{
		Session sess = new Util().getconnect();
		List<Employee> getall = sess.createQuery("from Employee").list();
		sess.close();
		return getall;
	}
	
	
	public Employee getSingle(Employee p)
	{
		Session sess = new Util().getconnect();
		Employee person = (Employee) sess.get(Employee.class, p.getId());
		sess.close();
		return person;
	}
}
