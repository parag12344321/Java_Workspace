import javax.servlet.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;

public class RegisterServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieving the form data from the request
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        
        // Here you can add your business logic like saving the data to the database
        // For this example, we are simply printing the data to the console
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
        System.out.println("Email: " + email);
        
        // Add attributes to request that you want to send to the JSP
        request.setAttribute("username", username);
        request.setAttribute("email", email);
        
        // Forwarding the request to a result JSP
        RequestDispatcher dispatcher = request.getRequestDispatcher("registrationResult.jsp");
        dispatcher.forward(request, response);
    }
}
