import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.*;

@WebServlet("/LifecycleServlet")
public class LifecycleServlet extends HttpServlet {

    private StringBuilder logMessages = new StringBuilder();

    @Override
    public void init() throws ServletException {
        logMessages.append("Servlet is being initialized...\n");
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        logMessages.append("Service method executed...\n");
        res.setContentType("text/plain");
        PrintWriter out = res.getWriter();
        out.println(logMessages.toString());
    }

    @Override
    public void destroy() {
        logMessages.append("Servlet is being destroyed...\n");
    }
}

