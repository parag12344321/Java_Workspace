package com.courses;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity 
@Table(name="Course1")
public class Course 
{
	
	@Id
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment",strategy="increment")
	@Column(name="courseid")
	int cid;
	
	@Column(name="coursename")
	String coursenm;

	public int getAid() {
		return cid;
	}

	public void setAid(int aid) {
		this.cid = aid;
	}

	public String getAnswer() {
		return coursenm;
	}

	public void setAnswer(String answer) {
		this.coursenm = answer;
	}
	
	
	
}
