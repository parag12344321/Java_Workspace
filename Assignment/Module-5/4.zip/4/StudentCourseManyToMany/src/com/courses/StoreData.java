package com.courses;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class StoreData 
{
	public static void main(String[] args) {
		
		
		   StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
		    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
		    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
		    Session session=factory.openSession();  
		    Transaction t=session.beginTransaction();    
		        
		    
		    
		
		Course an1=new Course();
		an1.setAnswer("Java ");
		
		
		Course an2=new Course();
		an2.setAnswer("Php");
			   
		Student q1=new Student();
		q1.setQname("Parag Mehta");
		
		ArrayList<Course> l1=new ArrayList<Course>();
		l1.add(an1);
		l1.add(an2);
		q1.setAnswers(l1);
		
		  Course ans3=new Course();  
		    ans3.setAnswer(".Net");  
		    
		      
		    Course ans4=new Course();  
		    ans4.setAnswer("Data Analysys");  
		   
		
		Student q2=new Student();
		q2.setQname("Vishal Parekh");
		
		ArrayList<Course> l2=new ArrayList<Course>();
		l2.add(ans3);
		l2.add(ans4);
		q2.setAnswers(l2);
		
		session.persist(q1);  
	    session.persist(q2);  
	      
	    t.commit();  
	    session.close();  
	    System.out.println("success");  
		
	}
}
