package com.controller;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bo.Bo;
import com.model.Employee;

public class Insert 
{
	public static void main(String[] args) 
	{
		
		ApplicationContext acm = new ClassPathXmlApplicationContext("tops.xml");
		Bo bo = (Bo) acm.getBean("bo");
		Employee p  =  (Employee) acm.getBean("model");
		
		//insert data
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Name");
		p.setName(sc.next());
		bo.Insert(p);
		System.out.println("Enter Department Name");
		p.setDepartment(sc.next());
		bo.Insert(p);
	}

}
