package com.controller;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bo.Bo;
import com.model.Employee;

public class Delete 
{
	
	public static void main(String[] args) 
	{
		
		ApplicationContext acm = new ClassPathXmlApplicationContext("tops.xml");
		Bo bo = (Bo) acm.getBean("bo");
		Employee p  =  (Employee) acm.getBean("model");
		
		//delete data
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee id");
		p.setId(sc.nextInt());
		bo.Delete(p);
	}

}
