package com.bo;

import com.dao.DAO;
import com.model.Employee;

public class Bo 
{
	DAO dao;

	public DAO getDao() {
		return dao;
	}

	public void setDao(DAO dao) {
		this.dao = dao;
	}
	
	public void Insert(Employee p)
	{
		dao.Insert(p);
	}
	public void Update(Employee p)
	{
		this.dao.Update(p);
	}
	
	public void Delete(Employee p)
	{
		this.dao.Delete(p);
	}
	
}
