package com.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.model.Employee;

public class DAO extends HibernateDaoSupport 
{

	
	public void Insert(Employee p)
	{
		this.getHibernateTemplate().save(p);
	}
	
	public void Update(Employee p)
	{
		this.getHibernateTemplate().update(p);
	}
	
	public void Delete(Employee p)
	{
		this.getHibernateTemplate().delete(p);
	}
	
}
