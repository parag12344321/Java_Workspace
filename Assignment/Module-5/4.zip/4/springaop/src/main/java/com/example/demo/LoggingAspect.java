package com.example.demo;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import java.util.logging.Logger;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = Logger.getLogger(LoggingAspect.class.getName());

    // Define a Pointcut for methods within the service package (you can adjust this)
    @Pointcut("execution(* com.example.demo.service.*.*(..))")
    public void serviceLayer() {}

    // @Before advice: Logs before method execution
    @Before("serviceLayer()")
    public void logBeforeMethod(JoinPoint joinPoint) {
        logger.info("Executing method: " + joinPoint.getSignature().getName());
    }

    // @After advice: Logs after method execution
    @After("serviceLayer()")
    public void logAfterMethod(JoinPoint joinPoint) {
        logger.info("Executed method: " + joinPoint.getSignature().getName());
    }

    // @Around advice: Logs before and after method execution, and calculates execution time
    @Around("serviceLayer()")
    public Object logExecutionTime(JoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        Object result = joinPoint.proceed();  // Proceed with method execution
        long end = System.currentTimeMillis();
        logger.info("Execution time of " + joinPoint.getSignature().getName() + " is " + (end - start) + " ms");
        return result;
    }
}