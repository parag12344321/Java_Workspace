package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class MyService {

    public String performAction() {
        try {
            Thread.sleep(500); // Simulate some work
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "Action performed!";
    }
}
