package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadDownloadApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadDownloadApiApplication.class, args);
	}

}
