package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="user")
public class User 
{
	@Id
	@GeneratedValue(generator="increment")//id
	@GenericGenerator(name="increment",strategy="increment")
	@Column(name="uid")//colname=pid
	private int id;
	
	@Column(name="uname")//colname=pname
	private String uname12;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return uname12;
	}
	public void setName(String name) {
		this.uname12 = name;
	}
	

}
