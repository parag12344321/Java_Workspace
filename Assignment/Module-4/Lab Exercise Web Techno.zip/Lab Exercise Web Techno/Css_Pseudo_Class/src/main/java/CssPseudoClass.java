
public class CssPseudoClass {

}
