
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.*;


@WebServlet("/index")
public class SimpleServlet extends HttpServlet {
    
    // Override the doGet method to handle HTTP GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the response content type
        response.setContentType("text/html");

        // Get the writer object to send the response
        PrintWriter out = response.getWriter();

        // Get parameters from the URL (query parameters)
        String name = request.getParameter("name");
        String age = request.getParameter("age");

        // Send HTML response
        out.println("<html><head><title>Simple Servlet</title></head><body>");
        out.println("<h2>Welcome to the Simple Servlet</h2>");

        if (name != null && !name.isEmpty()) {
            out.println("<p>Hello, " + name + "!</p>");
        } else {
            out.println("<p>Hello, anonymous user!</p>");
        }

        if (age != null && !age.isEmpty()) {
            out.println("<p>You are " + age + " years old.</p>");
        } else {
            out.println("<p>Your age is not provided.</p>");
        }

        out.println("</body></html>");
    }
}
