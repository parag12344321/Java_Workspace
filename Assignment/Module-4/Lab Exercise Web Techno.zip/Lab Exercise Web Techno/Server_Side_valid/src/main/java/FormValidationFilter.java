import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter("/*") // Apply this filter to all requests, or specify your form URL path here
public class FormValidationFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Filter initialization (optional)
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // Only check for POST requests (form submissions)
        if ("POST".equalsIgnoreCase(httpRequest.getMethod())) {
            // Get form parameters and check if any are empty
            String field1 = httpRequest.getParameter("field1");
            String field2 = httpRequest.getParameter("field2");
            // Add checks for more fields as needed

            if (isEmpty(field1) || isEmpty(field2)) {
                // If any field is empty, redirect back to the form page
                httpResponse.sendRedirect(httpRequest.getHeader("Referer"));
                return;
            }
        }

        // If validation passes, continue with the request
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Clean up any resources (optional)
    }

    private boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }
}
