import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.util.logging.Logger;

@WebListener  // Annotation to mark this class as a listener
public class ApplicationLifecycleListener implements ServletContextListener {

    private static final Logger logger = Logger.getLogger(ApplicationLifecycleListener.class.getName());

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // Application start event
        logger.info("Application started.");
        // You can log additional information such as system properties or initialization data here
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // Application stop event
        logger.info("Application stopped.");
        // You can log additional cleanup tasks or shutdown data here
    }
}
