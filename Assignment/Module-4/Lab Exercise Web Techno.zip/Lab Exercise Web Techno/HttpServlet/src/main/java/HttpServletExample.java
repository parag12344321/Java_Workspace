import java.io.*;
import javax.servlet.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/httpservlet")
public class HttpServletExample extends HttpServlet {

    // Override the doGet method to handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the content type of the response
        response.setContentType("text/html");

        // Write response using PrintWriter
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>HttpServlet: Hello World</h2>");
        out.println("</body></html>");
    }

    // Optionally, override doPost for POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);  // Delegate to doGet for simplicity
    }
}
