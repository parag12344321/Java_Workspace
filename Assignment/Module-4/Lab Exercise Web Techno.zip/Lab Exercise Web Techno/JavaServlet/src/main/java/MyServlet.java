import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet
{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
     	String n = req.getParameter("name");
		String s = req.getParameter("surname");
	    String p = req.getParameter("password");
		
		out.print("welcome");
		
//		if(p.equals("1234"))
//		{
//			out.print("welcome "+n);
//		}
//		else
//		{
//			resp.sendRedirect("404.html");
//		}
//		
//	}	

}
}
