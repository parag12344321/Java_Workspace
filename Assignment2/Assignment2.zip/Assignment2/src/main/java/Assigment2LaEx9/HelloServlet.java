package Assigment2LaEx9;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet 
{

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException 
    {
        // Set response content type
        response.setContentType("text/html");

        // Get parameters from the request
        String name = request.getParameter("name");
        String age = request.getParameter("age");

        // Prepare the response writer
        PrintWriter out = response.getWriter();
        
        // Generate HTML response
        out.println("<html><body>");
        if (name != null && age != null) {
            out.println("<h2>Hello, " + name + "!</h2>");
            out.println("<p>You are " + age + " years old.</p>");
        } else {
            out.println("<h2>Welcome to the Hello Servlet</h2>");
            out.println("<p>Please provide your name and age as parameters.</p>");
        }
        out.println("</body></html>");
    }
}