package Assignment2LabEx6;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/headers")
public class HeaderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Setting custom response headers
        response.setHeader("Custom-Header-1", "CustomHeaderValue1");
        response.setHeader("Custom-Header-2", "CustomHeaderValue2");
        
        // Set content type for the response
        response.setContentType("text/html");

        // Get writer to send HTML response
        PrintWriter out = response.getWriter();
        
        // Display request headers
        out.println("<html><body>");
        out.println("<h2>HTTP Request Headers</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>Header Name</th><th>Header Value</th></tr>");
        
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            String headerValue = request.getHeader(headerName);
            out.println("<tr><td>" + headerName + "</td><td>" + headerValue + "</td></tr>");
        }
        
        out.println("</table>");
        out.println("</body></html>");
    }
}
