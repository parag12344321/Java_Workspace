package Assignment2LabEx6;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class RequestHeaderDemo extends HttpServlet
{

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException 
    {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)

    throws IOException 
    {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("Headers<hr/>");

        Enumeration<String> headerNames = request.getHeaderNames();

        while (headerNames.hasMoreElements()) 
        {
            String headerName = headerNames.nextElement();
            out.print("Header Name: <em>" + headerName);
            
            String headerValue = request.getHeader(headerName);
            out.print("</em>, Header Value: <em>" + headerValue);
            
            out.println("</em><br/>");

        }
    }

}

