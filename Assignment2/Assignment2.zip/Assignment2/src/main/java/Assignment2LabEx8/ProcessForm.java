package Assignment2LabEx8;

//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.io.UnsupportedEncodingException;
//import java.net.URLDecoder;
//import java.util.HashMap;
//import java.util.Map;
//
//public class MyJavaCGIScript 
//{
//	
//	public static void main(String[] args) 
//	{
//        try 
//        {
//            // Print HTTP header
//            System.out.println("Content-Type: text/html\n");
//
//            // Read the form data from standard input
//            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
//            StringBuilder inputData = new StringBuilder();
//            String line;
//            while ((line = in.readLine()) != null)
//            {
//                inputData.append(line);
//            }
//
//            // Parse form data
//            Map<String, String> formData = parseFormData(inputData.toString());
//
//            // Generate HTML output
//            System.out.println("<html><head><title>Form Output</title></head><body>");
//            System.out.println("<h2>Form Data Received</h2>");
//            System.out.println("<p>Name: " + formData.get("name") + "</p>");
//            System.out.println("<p>Age: " + formData.get("age") + "</p>");
//            System.out.println("</body></html>");
//
//        } catch (Exception e) 
//        {
//            e.printStackTrace();
//        }
//    }
//
//    // Helper method to parse form data
//    private static Map<String, String> parseFormData(String data) throws UnsupportedEncodingException 
//    {
//        Map<String, String> formData = new HashMap<>();
//        String[] pairs = data.split("&");
//        for (String pair : pairs) 
//        {
//            String[] keyValue = pair.split("=");
//            String key = URLDecoder.decode(keyValue[0], "UTF-8");
//            String value = keyValue.length > 1 ? URLDecoder.decode(keyValue[1], "UTF-8") : "";
//            formData.put(key, value);
//        }
//        return formData;
//    }
//
//}

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ProcessForm extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Set the content type of the response
        response.setContentType("text/html");
        
        // Get the writer to send data to the browser
        PrintWriter out = response.getWriter();
        
        // Retrieve user input from the form
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        
        // Generate the HTML response
        out.println("<html><body>");
        out.println("<h1>Submitted Information</h1>");
        out.println("<p><b>Name:</b> " + name + "</p>");
        out.println("<p><b>Email:</b> " + email + "</p>");
        out.println("</body></html>");
        
        // Close the writer
        out.close();
    }
}

