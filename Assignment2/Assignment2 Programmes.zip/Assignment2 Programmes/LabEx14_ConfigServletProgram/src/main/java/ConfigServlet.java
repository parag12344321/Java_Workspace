import java.io.IOException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/ConfigServlet")
public class ConfigServlet extends HttpServlet {
    
    // Initialize the servlet
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        // Fetch initialization parameters from the ServletConfig object
        String param1 = config.getInitParameter("param1");
        String param2 = config.getInitParameter("param2");
        
        // Log the values or use them in your servlet
        System.out.println("param1: " + param1);
        System.out.println("param2: " + param2);
    }

    // Handle GET requests
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Set response content type
        response.setContentType("text/html");
        
        // Write the response content
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Servlet Config Parameters</h1>");
        
        // Access the parameters again in doGet (if needed)
        String param1 = getServletConfig().getInitParameter("param1");
        String param2 = getServletConfig().getInitParameter("param2");
        
        response.getWriter().println("<p>Param1: " + param1 + "</p>");
        response.getWriter().println("<p>Param2: " + param2 + "</p>");
        
        response.getWriter().println("</body></html>");
    }
}
