

import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

import java.io.*;

public class GenericServletExample extends GenericServlet {

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        // Initialization logic (e.g., setting up resources)
        System.out.println("GenericServlet initialized.");
    }

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        // This method is invoked for every request
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html><body>");
        out.println("<h1>Hello from GenericServlet!</h1>");
        out.println("</body></html>");
        
        System.out.println("Service method called in GenericServlet.");
    }

    @Override
    public void destroy() {
        // Cleanup logic (e.g., releasing resources)
        System.out.println("GenericServlet destroyed.");
    }
}
