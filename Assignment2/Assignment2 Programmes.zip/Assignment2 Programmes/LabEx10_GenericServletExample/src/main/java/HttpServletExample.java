
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;

public class HttpServletExample extends HttpServlet {

    @Override
    public void init() throws ServletException {
        // Initialization logic
        System.out.println("HttpServlet initialized.");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handling GET requests
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html><body>");
        out.println("<h1>Hello from HttpServlet!</h1>");
        out.println("</body></html>");
        
        System.out.println("doGet method called in HttpServlet.");
    }

    @Override
    public void destroy() {
        // Cleanup logic
        System.out.println("HttpServlet destroyed.");
    }
}
